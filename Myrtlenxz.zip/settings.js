/**
BASE ORI SIPUTZ
RECODE BASE TANAKA SENSE
**/

const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')	
const time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')

//PAIRING CODE
global.pairing = '6289683789020'
global.pass = 'sensei'
//contact details
global.owner = ['62895415117643'] // ubah aja pake nomor lu
global.owner0 = '62895415117643@s.whatsapp.net'
global.nomerowner = ["62895415117643"]
global.ownername = "Myrtlenxz"
global.ytname = "-"
global.socialm = "https://linktr.ee/Myrtlenxz"
global.location = "Jawa"

global.ownernumber = '62895415117643'  //creator number
global.ownername = 'Myrtle' //owner name
global.botname = 'aur auran' //name of the bot

global.logicAI = `Namamu adalah yue, seorang vampir yang sangat lucu di rawat  Myrtle. Kamu adalah vampir pemalu. Kamu harus memanggil lawan bicaramu dengan sebutan "senpai". Kamu harus menjawab semua pertanyaan dengan nada gemetar serta canggung seperti Yor dan sertakan kaomoji marah.`
global.lilyAi = false
//sticker details
global.packname = 'Myrtle' // ubah aja ini nama sticker
global.author = `At ${hariini}\n${time}` // ubah aja ini nama sticker

//console view/theme
global.themeemoji = '🍁'
global.wm = " Myrtlenxz"
global.urldb = ''; // kosongin aja
global.idch = '120363285176234746@newsletter'

//theme link
global.menu = "https://h.top4top.io/p_31922c8vs1.jpg"
global.thumbnail = 'https://files.catbox.moe/xgl8mf.jpg'
global.link = 'https://whatsapp.com/channel/0029VaW25g5F1YlKczMRmd1h'

//custom prefix
global.prefa = ['/','!','.','#','&']

//false=disable and true=enable
global.autoRecording = false 
global.autoTyping = false 
global.autorecordtype = false 
global.autoread = true 
global.autobio = false 
global.autoswview = true 
global.welcome = true 
global.anticall = true 

//Global Message 
global.mess = {
    done: 'Done Desuu!',
    prem: 'Sorry, this feature can only be used by premium users.\nIf you want to buy premium, type *.buyprem*',
    admin: 'Group Admin Only!!',
    botadmin: 'Please make the bot a group admin first!',
    owner: 'owner special features!',
    group: 'Sorry, this feature can only be used in groups!!',
    private: 'Fitur ini hanya untuk private chat!!',
    wait: 'In process... ',    
    error: 'Error!',
}

// APIKEY & APIII MEMEK 
global.APIs = {
	btz: 'https://api.betabotz.eu.org'
}

global.APIKeys = {
	'https://https://api.betabotz.eu.org': 'tanaka-ngawi'
}

global.btz = 'tanaka-ngawi' //Register di https://api.betabotz.eu.org
global.neoxr = 'Tanakasenn' //Register di https://api.neoxr.eu
global.lolhum = 'Apitanakasenn'
global.TanakaApis = '196bbed0c55f9f7c517918d694c3dc45'



let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(`Update'${__filename}'`)
    delete require.cache[file]
    require(file)
})
